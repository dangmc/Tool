.. cmake-module:: ../../Modules/FindICU.cmake
