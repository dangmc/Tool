.. cmake-module:: ../../Modules/AddFileDependencies.cmake
