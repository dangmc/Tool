.. cmake-module:: ../../Modules/CheckIncludeFile.cmake
