.. cmake-module:: ../../Modules/FindOpenACC.cmake
