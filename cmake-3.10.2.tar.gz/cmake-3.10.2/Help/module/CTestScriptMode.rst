.. cmake-module:: ../../Modules/CTestScriptMode.cmake
