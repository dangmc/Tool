.. cmake-module:: ../../Modules/Findosg.cmake
